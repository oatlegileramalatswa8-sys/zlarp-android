# ZLARP Android — early remake project

This project is an Android starter, not a direct IPA conversion and not an official ZLARP release.

## What was found in the supplied IPA
The IPA contains a compiled iOS app (`xyz.justsal.Blox`, version 0.1.0), an iOS ARM64 executable,
a small set of font files, app icons, and an asset catalog. It does not contain Android source
code or the original editable project. The compiled iOS executable cannot be turned into an APK
by renaming or simple conversion.

## Current prototype
- Android launcher screen
- Permission request for display-over-other-apps
- Draggable floating menu
- Home, Account, Tools, Settings placeholders
- Original app font and icon files are included under `reference-assets/`

The menu entries are visual placeholders; they do not perform ZLARP's original actions or connect
to Roblox. Rebuilding real behavior requires source code, documentation, or observable examples.

## Build an APK
1. Install Android Studio and Android SDK Platform 35 on a computer.
2. Open this folder in Android Studio and let Gradle sync.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on Samsung
Transfer the APK to the phone, open it, and allow installation from that source if Android asks.
Open ZLARP Android, grant display-over-other-apps permission, then tap Open floating panel.
