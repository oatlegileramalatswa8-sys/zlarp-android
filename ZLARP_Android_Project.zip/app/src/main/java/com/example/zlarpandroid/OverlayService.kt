package com.example.zlarpandroid

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var manager: WindowManager
    private var panel: LinearLayout? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null && android.provider.Settings.canDrawOverlays(this)) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        manager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(24, 22, 30))
        }
        val heading = TextView(this).apply {
            text = "ZLARP  •  MENU"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 14)
        }
        view.addView(heading)
        listOf("Home", "Account", "Tools", "Settings").forEach { name ->
            view.addView(TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(12, 12, 36, 12)
                setOnClickListener {
                    // Placeholder only: original ZLARP feature behavior is not present.
                }
            })
        }
        view.addView(TextView(this).apply {
            text = "CLOSE"
            textSize = 13f
            setTextColor(Color.rgb(205, 160, 255))
            setPadding(12, 14, 12, 4)
            setOnClickListener { stopSelf() }
        })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

        var downX = 0f; var downY = 0f; var originX = 0; var originY = 0
        heading.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    originX = params.x; originY = params.y; true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = originX + (event.rawX - downX).toInt()
                    params.y = originY + (event.rawY - downY).toInt()
                    manager.updateViewLayout(view, params); true
                }
                else -> false
            }
        }
        panel = view
        manager.addView(view, params)
    }

    override fun onDestroy() {
        panel?.let { try { manager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
